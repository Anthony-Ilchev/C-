#include "DNASeq.h"

char DNAStrand::getComplement(char nucleotide) {
    switch (nucleotide) {
        case 'A': return 'T';
        case 'T': return 'A'; //all potential dna bases 
        case 'C': return 'G';
        case 'G': return 'C';
        default: return 'X'; //invalid marker 
    }
}

DNAStrand::DNAStrand(const std::string& seq) {
    for (char c : seq) {
        sequence.pushBack(c);
    }
}

bool DNAStrand::isBases() const {  //returns true if strand is ATCG, retruns false if the nuceoltide is something else
    for (int i = 0; i < sequence.getSize(); i++) {
        char c = sequence.at(i);
        if (c != 'A' && c != 'T' && c != 'C' && c != 'G') {
            return false;
        }
    }
    return true;
}

DNAStrand DNAStrand::complement() const {  //creates new strand that is replaced with its complement
    DNAStrand result;
    for (int i = 0; i < sequence.getSize(); i++) {
        result.sequence.pushBack(getComplement(sequence.at(i)));
    }
    return result;
}

DNAStrand DNAStrand::substring(int start, int end) const {
    if (start < 0 || end > sequence.getSize() || start >= end) {
        throw std::out_of_range("Invalid substring range");
    }
    
    DNAStrand result;
    for (int i = start; i < end; i++) {
        result.sequence.pushBack(sequence.at(i));
    }
    return result;
}

bool DNAStrand::isGeneticPalindrome() const { //reading the DNA strands compliment is essentailly the paldindrome of the DNA seq
    if (!isBases()) return false;
    
    DNAStrand comp = complement();
    int size = sequence.getSize();
    
    for (int i = 0; i < size; i++) {
        if (sequence.at(i) != comp.sequence.at(size - 1 - i)) {
            return false;
        }
    }
    return true;
}

std::string DNAStrand::toString() const {  //creates DNA seq as a string 
    std::string result;
    for (int i = 0; i < sequence.getSize(); i++) {
        result += sequence.at(i);
    }
    return result;
}

int DNAStrand::length() const {
    return sequence.getSize();
}
