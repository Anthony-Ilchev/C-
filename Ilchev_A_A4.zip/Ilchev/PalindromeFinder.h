#ifndef PALINDROMEFINDER_H
#define PALINDROMEFINDER_H

#include <vector>
#include <string>
#include "DNASeq.h"

class PalindromeFinder {
public:
    static std::vector<std::string> findPalindromeSubstrings(const DNAStrand& seq);
};

#endif 