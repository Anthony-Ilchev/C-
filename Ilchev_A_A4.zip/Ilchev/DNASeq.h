#ifndef DNASeq_H
#define DNASeq_H

#include <string>
#include "DblList.h"

class DNAStrand {
private:
    DblList<char> sequence; //stores dna seq as doubly linked list 
    static char getComplement(char nucleotide);
    
public:
    DNAStrand() = default;  //creates empty DNA seq 
    explicit DNAStrand(const std::string& seq); //from string input
    
    bool isBases() const;  //is valid is bool that checks contains valid bases 
    DNAStrand complement() const;
    DNAStrand substring(int start, int end) const;
    bool isGeneticPalindrome() const;
    std::string toString() const;
    int length() const;
};

#endif 
