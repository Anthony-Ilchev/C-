1)	
    a.	Anthony Ilchev  
    b.	2456082
    c.	ilchev@chapman.edu
    d.	350-03
    e.	Coding Assingment 4

2)	List of all source files
  dbllist.h, dnaseq.cpp dnaseq.h main.cpp Makefile palindromefinder.h palindromefiner.cpp



3)	A description of any known syntax or runtime errors, code limitations, or deviations from the assignment specification (if applicable) 
 output adds an extra person for each column at 0.0 

4)	A list of all references used to complete the assignment, including peers (if applicable) 
stack overflow
chatpgt for the DNAseq. cpp and .h files 
my family friend that works in industry for dbllist and the main file, additonally adding a makefile to it and explaining to me what a make files etc.




compile : make
run : ./dna_analyzer input.txt


