#include "PalindromeFinder.h"

std::vector<std::string> PalindromeFinder::findPalindromeSubstrings(const DNAStrand& seq) {
    std::vector<std::string> palindromes;
    int len = seq.length();
    
    // Check all possible substrings of length > 4 and < len
    for (int length = 5; length < len; length++) {
        for (int start = 0; start <= len - length; start++) {
            DNAStrand substr = seq.substring(start, start + length);
            if (substr.isGeneticPalindrome()) {
                palindromes.push_back(substr.toString());
            }
        }
    }
    
    return palindromes;
}