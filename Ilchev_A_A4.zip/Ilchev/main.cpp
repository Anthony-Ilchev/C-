#include <iostream>
#include <fstream>
#include <string>
#include "PalindromeFinder.h"

int main(int argc, char* argv[]) {
    if (argc != 2) {
        std::cerr << "Usage: " << argv[0] << " <input_file>" << std::endl;
        return 1;
    }
    
    std::ifstream inFile(argv[1]); //open input file 
    if (!inFile) {
        std::cerr << "Error opening file: " << argv[1] << std::endl;
        return 1;
    }
    
    std::string line;
    while (std::getline(inFile, line) && line != "END") {
        DNAStrand sequence(line); //prcoess line till END is reached on the file 
        std::cout << line; //creating DNA object from input line 
        
        if (!sequence.isBases()) {
            std::cout << " - INVALID" << std::endl;
            continue;
        }
        // check to see if valid bases 
        if (sequence.isGeneticPalindrome()) {
            std::cout << " - This is a Genetic Palindrome" << std::endl;
        } else {
            std::cout << " - This is not Genetic Palindrome" << std::endl;
        }
        // if the sequences is longer then 4 bases check for substrings 
        if (sequence.length() > 4) {
            std::vector<std::string> palindromes = 
                PalindromeFinder::findPalindromeSubstrings(sequence);
            for (const auto& palindrome : palindromes) {
                std::cout << "\tSubstring " << palindrome 
                         << " - This is a Genetic Palindrome" << std::endl;
            }
        }
    }
    
    inFile.close();
    return 0;
}