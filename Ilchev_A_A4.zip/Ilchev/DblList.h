#ifndef DBLLIST_H
#define DBLLIST_H

#include <stdexcept>

template <typename T>
class DblList {
private:
    struct Node {
        T data;
        Node* next;
        Node* prev;
        
        Node(const T& item) : data(item), next(nullptr), prev(nullptr) {}
    };
    
    Node* head;
    Node* tail;
    int size;

public:
    DblList() : head(nullptr), tail(nullptr), size(0) {}
    
    ~DblList() {
        while (head != nullptr) {
            Node* temp = head;
            head = head->next;
            delete temp;
        }
    }
    
    void pushBack(const T& item) {
        Node* newNode = new Node(item);
        if (tail == nullptr) {
            head = tail = newNode;
        } else {
            tail->next = newNode;
            newNode->prev = tail;
            tail = newNode;
        }
        size++;
    }
    
    T& at(int index) {
        if (index < 0 || index >= size) {   //loop through list to find node 
            throw std::out_of_range("Out of Bounds");
        }
        Node* current = head;
        for (int i = 0; i < index; i++) {
            current = current->next;
        }
        return current->data;
    }
    
    const T& at(int index) const {  //use when dbl is constant 
        if (index < 0 || index >= size) {
            throw std::out_of_range("Out of Bounds");
        }
        Node* current = head;
        for (int i = 0; i < index; i++) {
            current = current->next;
        }
        return current->data;
    }
    
    int getSize() const { return size; }
    //check if list is empy retruns true and false 
    bool isEmpty() const { return size == 0; }
};

#endif 
