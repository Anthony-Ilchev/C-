#ifndef SPEAKERVIEW_H
#define SPEAKERVIEW_H

#include "MonoStack.h"
#include <iostream>
#include <fstream>
#include <sstream>
#include <iomanip>
#include <stdexcept>

class SpeakerView {
private:
    double** heights;
    int numRows;
    int numCols;

public:
    SpeakerView() : heights(nullptr), numRows(0), numCols(0) {} //constructor 

    ~SpeakerView() {
        for (int i = 0; i < numRows; ++i) { //destructor 
            delete[] heights[i];
        }
        delete[] heights;
    }

    void readFile(const std::string& filename) {  //reading file 
        std::ifstream file(filename);
        std::string line;

        if (!file.is_open()) {
            throw std::runtime_error("file could not be opened");
        }

        std::getline(file, line); // Skipping the begin portion

        numRows = 0;
        while (std::getline(file, line) && line != "END") {
            ++numRows;
            std::istringstream iss(line);
            double height;
            int currentCols = 0;
            while (iss >> height) {
                ++currentCols;
            }
            if (numCols == 0) numCols = currentCols;
        }

        heights = new double*[numRows];
        file.clear();
        file.seekg(0);
        std::getline(file, line); //skip begin 

        for (int i = 0; i < numRows; ++i) {  //iterating through array 
            heights[i] = new double[numCols];
            std::getline(file, line);
            std::istringstream iss(line);
            for (int j = 0; j < numCols; ++j) {
                iss >> heights[i][j];
            }
        }
        file.close();
    }

    
    void Visibility() {
        for (int col = 0; col < numCols; ++col) {
            MonoStack<double> stack(numRows, 'd');
            double* visibleHeights = new double[numRows]; // array to hold people
            int visCount = 0; // count people who can see 

            for (int row = 0; row < numRows; ++row) {
                double height = heights[row][col];

                // if the current height is taller than the top of the stack
                while (!stack.isEmpty() && stack.peek() <= height) {
                    stack.pop();
                }

                // If the stack empty this person can see
                if (stack.isEmpty()) {
                    visibleHeights[visCount++] = height; // Store the visible height
                }

                stack.push(height); // push height of stack
            }

            //output result 
            std::cout << "In column " << col << " there are " << visCount
                      << " that can see. Their heights are: ";

            for (int i = 0; i < visCount; ++i) {
                std::cout << std::fixed << std::setprecision(1) << visibleHeights[i]
                          << (i < visCount - 1 ? ", " : " inches.\n");
            }

            delete[] visibleHeights; 
        }
    }
};

#endif

