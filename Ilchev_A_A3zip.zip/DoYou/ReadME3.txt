1)	
    a.	Anthony Ilchev  
    b.	2456082
    c.	ilchev@chapman.edu
    d.	350-03
    e.	Coding Assingment 3

2)	List of all source files
   monostack.h speakerview.h main.cpp



3)	A description of any known syntax or runtime errors, code limitations, or deviations from the assignment specification (if applicable) 
 output adds an extra person for each column at 0.0 

4)	A list of all references used to complete the assignment, including peers (if applicable) 
stackoverflow to make the monotonous stack, and chatgpt to outline the code for my speakerview class
and my family friend in the industry for overall coding help. 


compile :g++ main.cpp -o main
run : ./main input.txt


