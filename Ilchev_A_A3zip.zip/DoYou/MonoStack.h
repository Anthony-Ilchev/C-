#ifndef MONOSTACK_H
#define MONOSTACK_H

#include <iostream>
#include <stdexcept>

template<typename T>
class MonoStack {
private:
    T* stack; //pointer to array for stack elements 
    int top;
    int capacity;
    char order; // 'i' increases 'd' decreases 

public:
    MonoStack(int size, char o) : top(-1), capacity(size), order(o) {
        stack = new T[capacity]; //intizalizes stack 
    }

    ~MonoStack() { //destrcutor 
        delete[] stack;
    }

    void push(T value) {
        if (top == capacity - 1) {
            throw std::overflow_error("Stack overflow"); //checks for stack overflow
        }
        while (top != -1 && (order == 'd' ? stack[top] < value : stack[top] > value)) {
            top--;
        }
        stack[++top] = value;
    }
    //pops and returns top value of stack 
    T pop() {
        if (top == -1) {  
            throw std::underflow_error("Stack underflow");
        }
        return stack[top--]; 
    }

    T peek() const {
        if (top == -1) {
            throw std::underflow_error("Stack is empty");
        }
        return stack[top];
    }

    bool isEmpty() const {
        return top == -1;  //returns true if top is -1 
    }
};

#endif // MONOSTACK_H
