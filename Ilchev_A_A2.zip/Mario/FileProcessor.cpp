#include "FileProcessor.h"
#include "World.h"
#include "Mario.h"
#include <iostream>
#include <fstream>
#include <string>

FileProcessor::FileProcessor(){ //default constructor
}

FileProcessor::~FileProcessor(){ //deconstsructor
}

void FileProcessor::processFile(std::string inputFile, int* fileInputs)
{
    std::ifstream fileToRead; 
    
    std::string fileLine;
    int fileSize = 8; // set size, because we have predetermined size 

    fileToRead.open(inputFile);

    if (!fileToRead.is_open()) 
    {
        std::cout << "Couldn't open " << inputFile << std::endl;
        return;
    }
   
    if(fileToRead.is_open()) 
    {
        for (int i = 0; i < fileSize; i++) //read array line by line
        {
            fileToRead >> fileInputs[i]; 
        }
    }

    fileToRead.close();
}