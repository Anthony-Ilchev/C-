#ifndef FILEPROCESSOR_H
#define FILEPROCESSOR_H

#include <string>

class FileProcessor
{
    public:
        FileProcessor();
        ~FileProcessor();
        void processFile(std::string inputFile, int* fileInputs);

    private:
        int* fileInputs; //array to store value of files 
};

#endif