1)	
    a.	Anthony Ilchev  
    b.	2456082
    c.	ilchev@chapman.edu
    d.	350-03
    e.	Coding Assingment 5

2)	List of all source files
 main.cpp DOTFileGenerator.cpp Monster.h TournamentTree.h TournamentNode.h



3)	A description of any known syntax or runtime errors, code limitations, or deviations from the assignment specification (if applicable) 


4)	A list of all references used to complete the assignment, including peers (if applicable) 
stackoverflow to help understand and use the dot file and posing chat gpt questions like how do you use a dot file etc., and chatgpt to help me implement the double elimination portion of the the project
and my family friend in the industry for overall coding help. 


compile : g++ -std=c++11 -o monster Main.cpp DOTFileGenerator.cpp
run: ./monster monsters.txt single/double depending on what you want


