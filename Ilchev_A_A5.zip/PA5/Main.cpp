#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include "Monster.h"
#include "TournamentTree.h"

// Declaration of saveTreeAsDot to generate the DOT file
void saveTreeAsDot(TournamentNode *root, const std::string &filename);

// Function to load monsters from a file
std::vector<Monster*> loadMonstersFromFile(const std::string &filename) {
    std::ifstream file(filename);
    if (!file) {
        throw std::runtime_error("Could not open file: " + filename);
    }

    std::vector<Monster*> monsters;
    std::string name;
    int screamPower;

    while (file >> name >> screamPower) {
        monsters.push_back(new Monster(name, screamPower));
    }

    file.close();
    return monsters;
}

int main(int argc, char *argv[]) {
    if (argc != 3) {
        std::cerr << "Usage: " << argv[0] << " <monsters_file> <tournament_type>" << std::endl;
        std::cerr << "Tournament type must be 'single' or 'double'." << std::endl;
        return 1;
    }

    std::string monstersFile = argv[1];
    std::string tournamentType = argv[2];

    try {
        // Load monsters from the file
        std::vector<Monster*> competitors = loadMonstersFromFile(monstersFile);

        // Create and run the tournament 
        if (tournamentType == "single") {
            std::cout << "starting single elim tournament" << std::endl;
            TournamentTree singleElimination(competitors);
            singleElimination.startSingleElimination();
            std::cout << "single elim inner: " << singleElimination.root->winner->toString() << std::endl;
            saveTreeAsDot(singleElimination.root, "SingleEliminationTree.dot");
        } else if (tournamentType == "double") {
            std::cout << "starting double elim ournament" << std::endl;
            TournamentTree doubleElimination(competitors);
            doubleElimination.startDoubleElimination();
            std::cout << "double elim winner: " << doubleElimination.root->winner->toString() << std::endl;
            saveTreeAsDot(doubleElimination.root, "DoubleEliminationTree.dot");
        } else {
            std::cerr << "Invalid tournament: " << tournamentType << std::endl;
            std::cerr << "Tournament type must be 'single' or 'double'." << std::endl;
            return 1;
        }

        // Clean up monsters
        for (size_t i = 0; i < competitors.size(); ++i) {
            delete competitors[i];
        }
    } catch (const std::exception &e) {
        std::cerr << "Error: " << e.what() << std::endl;
        return 1;
    }

    return 0;
}
