#ifndef TOURNAMENTTREE_H
#define TOURNAMENTTREE_H

#include <vector>
#include <iostream>
#include "TournamentNode.h"

class TournamentTree {
public:
    TournamentNode *root;
    std::vector<Monster*> competitors;

    TournamentTree(const std::vector<Monster*> &competitors) : competitors(competitors), root(nullptr) {}

    // starts the single elimination 
    void startSingleElimination() {
        std::cout << "starting single elim tournament..." << std::endl;
        root = buildSingleElimination(competitors);
    }

    // starts the double elimination 
    void startDoubleElimination() {
        std::cout << "starting double elim tournament..." << std::endl;

        //  winner's bracket
        root = buildSingleElimination(competitors);

        // losers from the winner's bracket
        std::vector<Monster*> losersBracket = collectLosers(root);

        //  loser's bracket
        TournamentNode *losersRoot = buildSingleElimination(losersBracket);

        // winners bracket vs winner of the loser's bracket
        root = new TournamentNode(root->winner, losersRoot->winner);
        std::cout << "Final match between winner's bracket winner: " << root->winner->toString()
                  << " and loser's bracket winner: " << losersRoot->winner->toString() << std::endl;
    }

    ~TournamentTree() {
        delete root;
    }

private:
    // build the single elimination tree
    TournamentNode* buildSingleElimination(const std::vector<Monster*> &competitors) {
        if (competitors.size() == 1) {
            std::cout << "single competitor: " << competitors[0]->toString() << std::endl;
            return new TournamentNode(competitors[0]); // Base case: single competitor
        }

        std::vector<Monster*> nextRoundCompetitors;
        for (size_t i = 0; i < competitors.size(); i += 2) {
            if (i + 1 < competitors.size()) {
                // match between two competitors
                TournamentNode *match = new TournamentNode(competitors[i], competitors[i + 1]);
                std::cout << "match between " << competitors[i]->toString() << " and " 
                          << competitors[i + 1]->toString() << ", winner: " 
                          << match->winner->toString() << std::endl;
                nextRoundCompetitors.push_back(match->winner);
            } else {
                // Odd number of competitors, move foward 
                std::cout << "advancing " << competitors[i]->toString() << " automatically" << std::endl;
                nextRoundCompetitors.push_back(competitors[i]);
            }
        }
        return buildSingleElimination(nextRoundCompetitors); // Recursively proceed to the next round
    }

    // losers from each match in the winners bracket for the losers bracket
    std::vector<Monster*> collectLosers(TournamentNode *node) {
        if (!node || (!node->left && !node->right)) {
            return std::vector<Monster*>();
        }

        std::vector<Monster*> losers;
        if (node->left && node->left->winner != node->winner) {
            losers.push_back(node->left->winner);
        }
        if (node->right && node->right->winner != node->winner) {
            losers.push_back(node->right->winner);
        }

        std::vector<Monster*> leftLosers = collectLosers(node->left);
        std::vector<Monster*> rightLosers = collectLosers(node->right);

        losers.insert(losers.end(), leftLosers.begin(), leftLosers.end());
        losers.insert(losers.end(), rightLosers.begin(), rightLosers.end());

        return losers;
    }
};

#endif // TOURNAMENTTREE_H
