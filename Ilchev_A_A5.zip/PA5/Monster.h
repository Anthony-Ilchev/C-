#ifndef MONSTER_H
#define MONSTER_H

#include <string>

class Monster {
public:
    std::string name;
    int screamPower;

    Monster(const std::string &name, int screamPower) : name(name), screamPower(screamPower) {}

    bool operator<(const Monster &other) const {
        return screamPower < other.screamPower;
    }

    bool operator>(const Monster &other) const {
        return screamPower > other.screamPower;
    }

    std::string toString() const {
        return name + " (" + std::to_string(screamPower) + ")";
    }
};

#endif // MONSTER_H
