#ifndef TOURNAMENTNODE_H
#define TOURNAMENTNODE_H

#include "Monster.h"

class TournamentNode {
public:
    Monster *winner;
    TournamentNode *left;
    TournamentNode *right;

    // Constructor for two competitors
    TournamentNode(Monster *comp1, Monster *comp2) : left(nullptr), right(nullptr) {
        if (comp1 && comp2) {
            winner = (*comp1 > *comp2) ? comp1 : comp2;
            left = new TournamentNode(comp1);
            right = new TournamentNode(comp2);
        } else if (comp1) {
            winner = comp1;
        } else {
            winner = comp2;
        }
    }

    // Constructor for a single competitor
    TournamentNode(Monster *comp) : winner(comp), left(nullptr), right(nullptr) {}

    ~TournamentNode() {
        delete left;
        delete right;
    }
};

#endif // TOURNAMENTNODE_H

