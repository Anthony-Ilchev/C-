#include <fstream>
#include <string>
#include "TournamentNode.h" 

//  declaration of saveNodeAsDot
void saveNodeAsDot(TournamentNode *node, std::ofstream &file);

// tree structure to a DOT file
void saveTreeAsDot(TournamentNode *root, const std::string &filename) {
    std::ofstream file(filename);
    file << "digraph TournamentTree {\n";
    saveNodeAsDot(root, file); // Recursively write each node and edge
    file << "}\n";
    file.close();
}

//  helper function for single node
void saveNodeAsDot(TournamentNode *node, std::ofstream &file) {
    if (!node || !node->winner) return; // Base case: empty node or no winner

    // label for the current node 
    std::string winnerLabel = node->winner->name + " (" + std::to_string(node->winner->screamPower) + ")";

    // left child and edge 
    if (node->left && node->left->winner) {
        std::string leftLabel = node->left->winner->name + " (" + std::to_string(node->left->winner->screamPower) + ")";
        file << "\"" << winnerLabel << "\" -> \"" << leftLabel << "\";\n";
        saveNodeAsDot(node->left, file); // left child
    }

    // right child and its edge
    if (node->right && node->right->winner) {
        std::string rightLabel = node->right->winner->name + " (" + std::to_string(node->right->winner->screamPower) + ")";
        file << "\"" << winnerLabel << "\" -> \"" << rightLabel << "\";\n";
        saveNodeAsDot(node->right, file); // right child
    }
}
